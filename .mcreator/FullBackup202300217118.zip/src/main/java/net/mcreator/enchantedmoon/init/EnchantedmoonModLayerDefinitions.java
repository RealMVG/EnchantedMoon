package net.mcreator.enchantedmoon.init;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.ModelLayerLocation;

public class EnchantedmoonModLayerDefinitions {
	public static final ModelLayerLocation MAGIC_CIRCLE = new ModelLayerLocation(new ResourceLocation("enchantedmoon", "magic_circle"), "magic_circle");
}
