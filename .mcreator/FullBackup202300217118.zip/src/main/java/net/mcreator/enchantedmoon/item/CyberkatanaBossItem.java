
package net.mcreator.enchantedmoon.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class CyberkatanaBossItem extends Item {
	public CyberkatanaBossItem() {
		super(new Item.Properties().tab(null).stacksTo(64).rarity(Rarity.COMMON));
	}
}
